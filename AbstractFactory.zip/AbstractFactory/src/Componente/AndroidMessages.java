package Componente;

import javax.swing.ImageIcon;
import java.io.IOException;

import javax.imageio.ImageIO;

import Main.CarClient;

public class AndroidMessages implements Messaging { // Clasa AndroidMessages implementeaza interfata Messaging

	private ImageIcon _image;

	@Override // Suprascrierea metodei abstrace din interfata
	public void creeazaComponenta() throws IOException {
		_image = new ImageIcon("res/icons/AndroidMessages.png");// implementarea metodei abstracte din interfata
	}

	@Override
	public ImageIcon deseneaza() { // functia returneaza imagine atunci cand este apelata in Componenta.java
		return _image;
	}

	@Override
	public String nume() {
		return "Android Messages"; // returneaza numele care va aparea atunci cand este apasat butonul pentru
									// aplicatie
	}
}
