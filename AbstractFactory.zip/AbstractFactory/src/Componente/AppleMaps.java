package Componente;

import javax.swing.ImageIcon;
import java.io.IOException;

import javax.imageio.ImageIO;

import Main.CarClient;

public class AppleMaps implements GPS { // Clasa AppleMaps implementeaza interfata GPS

	private ImageIcon _image;

	@Override // Suprascrierea metodei abstrace din interfata
	public void creeazaComponenta() throws IOException { // implementarea metodei abstracte din interfata
		_image = new ImageIcon("res/icons/AppleMaps.png");
	}

	@Override
	public ImageIcon deseneaza() { // functia returneaza imagine atunci cand este apelata in Componenta.java
		return _image;
	}

	@Override
	public String nume() { // returneaza numele care va aparea atunci cand este apasat butonul pentru
							// aplicatie
		return "AppleMaps";
	}
}
