package Componente;

public interface Assistant extends Componenta {
	// interfata Assistant extinde interfata Componenta oferand o implementare
	// specifica
	// in functie de butoanele create in Product_JFrame
}
