package Componente;

public interface Calendar extends Componenta {
	// interfata Calendar extinde interfata Componenta oferand o implementare
	// specifica
	// in functie de butoanele create in Product_JFrame
}
