package Componente;

import java.io.IOException;
import javax.swing.ImageIcon;
								
public interface Componenta {	

		void creeazaComponenta() throws IOException; // metoda abstracta care poate arunca o exceptie in cazul in care apare o problema in timpul executiei
		ImageIcon deseneaza();	// metodele deseneaza() si nume() sunt metode abstracte care aceseaza elementele unui buton 
		String nume();
		
}

