package Componente;

public interface GPS extends Componenta {
	// interfata GPS extinde interfata Componenta oferand o implementare specifica
	// in functie de butoanele create in Product_JFrame
}
