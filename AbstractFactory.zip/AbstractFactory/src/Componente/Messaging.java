package Componente;

public interface Messaging extends Componenta {
	// interfata Messaging extinde interfata Componenta oferand o implementare
	// specifica
	// in functie de butoanele create in Product_JFrame
}
