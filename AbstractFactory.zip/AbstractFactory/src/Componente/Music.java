package Componente;

public interface Music extends Componenta {
	// interfata Music extinde interfata Componenta oferand o implementare specifica
	// in functie de butoanele create in Product_JFrame
}
