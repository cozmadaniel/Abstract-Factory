package Componente;

public interface Podcast extends Componenta {

	// interfata Podcast extinde interfata Componenta oferand o implementare
	// specifica
	// in functie de butoanele create in Product_JFrame
}
