package Componente;

import javax.swing.ImageIcon;
import java.io.IOException;

import javax.imageio.ImageIO;

import Main.CarClient;

public class Siri implements Assistant {// Clasa Siri implementeaza interfata Assistant

	private ImageIcon _image;

	@Override // Suprascrierea metodei abstrace din interfata
	public void creeazaComponenta() throws IOException { // implementarea metodei abstracte din interfata
		_image = new ImageIcon("res/icons/Siri.png");
	}

	@Override
	public ImageIcon deseneaza() { // functia returneaza imagine atunci cand este apelata in Componenta.java
		return _image;
	}

	@Override
	public String nume() { // returneaza numele care va aparea atunci cand este apasat butonul pentru
							// aplicatie
		return "Siri";
	}
}
