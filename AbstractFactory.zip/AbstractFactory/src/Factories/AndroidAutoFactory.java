package Factories;

import javax.swing.ImageIcon;

import Componente.AndroidMessages;
import Componente.GoogleAssistant;
import Componente.GoogleCalendar;
import Componente.GoogleMaps;
import Componente.PocketCasts;
import Componente.Spotify;

public class AndroidAutoFactory extends CarFactory { /// Clasa AndroidAutoFactory extinde clasa abstracta CarFactory
														/// ceea ce inseamna ca trebuie sa furnizeze
														/// implementari concrete pentru metodele abstracte definite in
														/// CarFactory

	@Override /// suprascrierea metodei
	public AndroidMessages creeazaMesagerie() { /// Instantierea si returnarea unui obiect de tip `Android Messages`
		return new AndroidMessages();
	}

	@Override /// suprascrierea metodei
	public GoogleCalendar creeazaCalendar() { // Instantierea si returnarea unui obiect de tip `GoogleCalendar`
		return new GoogleCalendar();
	}

	@Override /// suprascrierea metodei
	public GoogleAssistant creeazaAsistent() { /// Instantierea si returnarea unui obiect de tip `GoogleAssistant`
		return new GoogleAssistant();
	}

	@Override /// suprascrierea metodei
	public GoogleMaps creeazaGPS() { /// Instantierea si returnarea unui obiect de tip `GoogleMaps`
		return new GoogleMaps();
	}

	@Override /// suprascrierea metodei
	public PocketCasts creeazaPodcast() { /// Instantierea si returnarea unui obiect de tip `PocketCasts`
		return new PocketCasts();
	}

	@Override /// suprascrierea metodei
	public Spotify creeazaMuzica() { /// Instantierea si returnarea unui obiect de tip `Spotify`
		return new Spotify();
	}

	@Override /// suprascrierea metodei
	public ImageIcon fundal() { /// Instantierea si returnarea unui obiect de tip ImagieIcon care va reprezenta
								/// fundalul
		return new ImageIcon("res/icons/android_wallpaper.jpg");
	}

}
