package Factories;

import javax.swing.ImageIcon;

import Componente.AppleCalendar;
import Componente.AppleMaps;
import Componente.AppleMusic;
import Componente.ApplePodcast;
import Componente.IMessage;
import Componente.Siri;

public class AppleCarPlayFactory extends CarFactory { /// Clasa AppleCarPlayFactory extinde clasa abstracta CarFactory
														/// ceea ce inseamna ca trebuie sa furnizeze
														/// implementari concrete pentru metodele abstracte definite in
														/// CarFactory

	@Override /// suprascrierea metodei
	public AppleMaps creeazaGPS() { /// Instantierea si returnarea unui obiect de tip `AndroidMessages`
		return new AppleMaps();
	}

	@Override /// suprascrierea metodei
	public AppleMusic creeazaMuzica() { /// Instantierea si returnarea unui obiect de tip `AppleMusic`
		return new AppleMusic();
	}

	@Override /// suprascrierea metodei
	public IMessage creeazaMesagerie() { /// Instantierea si returnarea unui obiect de tip `IMessage`
		return new IMessage();
	}

	@Override /// suprascrierea metodei
	public Siri creeazaAsistent() { /// Instantierea si returnarea unui obiect de tip `Siri`
		return new Siri();
	}

	@Override /// suprascrierea metodei
	public ApplePodcast creeazaPodcast() { /// Instantierea si returnarea unui obiect de tip `ApplePodcast`
		return new ApplePodcast();
	}

	@Override /// suprascrierea metodei
	public AppleCalendar creeazaCalendar() { /// Instantierea si returnarea unui obiect de tip `AppleCalendar`
		return new AppleCalendar();
	}

	@Override /// suprascrierea metodei
	public ImageIcon fundal() { /// Instantierea si returnarea unui obiect de tip ImagieIcon care va reprezenta
								/// fundalul
		return new ImageIcon("res/icons/carplay_wallpaper.png");
	}
}
