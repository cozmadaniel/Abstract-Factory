package Factories;

import javax.swing.ImageIcon;

import Componente.Assistant;
import Componente.Calendar;
import Componente.GPS;
import Componente.Messaging;
import Componente.Music;
import Componente.Podcast;

/*
	Clasa abstracta CarFactory este o interfata abstracta pentru fabricile de componente AndroidAutoFactory si AppleCarPlayFactory.
Sunt declarate o serie de metode abstracte fara implementare pentru crearea diverselor tipuri de componente.
 */

public abstract class CarFactory {
	public abstract Messaging creeazaMesagerie(); /// Metoda abstracta pentru crearea unui obiect de tip `Messaging`

	public abstract Calendar creeazaCalendar(); /// Metoda abstracta pentru crearea unui obiect de tip `Calendar`

	public abstract GPS creeazaGPS(); /// Metoda abstracta pentru crearea unui obiect de tip `GPS`

	public abstract Music creeazaMuzica(); /// Metoda abstracta pentru crearea unui obiect de tip `Music`

	public abstract Assistant creeazaAsistent(); /// Metoda abstracta pentru crearea unui obiect de tip `Assistant`

	public abstract Podcast creeazaPodcast(); /// Metoda abstracta pentru crearea unui obiect de tip `Podcast`

	public abstract ImageIcon fundal(); /// Metoda abstracta pentru crearea unui obiect de tip ImagieIcon care va
										/// reprezenta fundalul
}
