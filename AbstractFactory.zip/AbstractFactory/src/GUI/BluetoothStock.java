package GUI;

import javax.swing.*;

import Factories.AndroidAutoFactory;
import Factories.AppleCarPlayFactory;
import Factories.CarFactory;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BluetoothStock extends JFrame {
	/// Realizarea in GUI a primei interfete pentru meniul de conectare la
	/// dispozitivele BLuetooth
	public BluetoothStock() { // Customizarea interfetei
		setTitle("Bluetooth");
		setSize(900, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		String pathToImage = "res/icons/bluetooth_wallpaper.jpg";

		setLayout(null);

		setContentPane(new JLabel(new ImageIcon(pathToImage)));

		JLabel titleLabel = new JLabel("Bluetooth Devices");
		titleLabel.setForeground(Color.WHITE);
		titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
		titleLabel.setBounds(50, 20, 270, 70);
		add(titleLabel);

		// Adaugarea butoanelor drept dispozitive
		addButton("IPhone 15", 50, 80, "Se activeaza Apple Carplay");
		addButton("Galaxy S24", 50, 130, "Se activeaza Android Auto");

		setLocationRelativeTo(null);
		setVisible(true);
	}

	// Metoda de adaugare a butonului
	private void addButton(String buttonName, int x, int y, String popupMessage) {

		BluetoothStock that = this;

		JButton button = new JButton(buttonName);
		button.setPreferredSize(new Dimension(150, 30));
		button.setBounds(x, y, 150, 30);
		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Crearea unui obiect factory la apasarea butonului
				CarFactory factory = null;

				if (buttonName == "IPhone 15") // Verific ce buton am apasa, altfel spus, la ce telefon ma conectez
					factory = new AppleCarPlayFactory(); // Crearea fabricii specifice AppleCarPlayFactory() ce deschide
															// noua interfata
															// din Product_JFrame
				else
					factory = new AndroidAutoFactory(); // Crearea fabricii specifice AndroidAutoFactory() ce deschide
														// noua interfata
														// din Product_JFrame

				final CarFactory factory_impl = factory; // Copierea referintei la fabrica pentru a o face finala
				Product_JFrame frame = new Product_JFrame(factory_impl); // Crearea unei instante de Product_JFrame cu
																			// fabrica copiata
				frame.makeVisible();
				that.setVisible(false); // Ascunderea interfetei Bluetooth
			}
		});
		add(button);
	}

}
