package GUI;

import javax.swing.*;

import Componente.Componenta;
import Componente.Music;
import Factories.CarFactory;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Product_JFrame extends JFrame {
	// Realizarea interfetei GUI
	public Product_JFrame(CarFactory factory) {
		setTitle("Emulator");
		setSize(900, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Realizarea componentelor generice
		Componenta Assistant = factory.creeazaAsistent();
		Componenta Calendar = factory.creeazaCalendar();
		Componenta GPS = factory.creeazaGPS();
		Componenta Messaging = factory.creeazaMesagerie();
		Componenta Podcast = factory.creeazaPodcast();
		Componenta Music = factory.creeazaMuzica();

		setContentPane(new JLabel(factory.fundal())); // Stabilirea fundalului

		// Adaugarea propriu-zisa a butoanelor
		addButton(GPS, 175, 60);
		addButton(Music, 375, 60);
		addButton(Calendar, 575, 60);
		addButton(Messaging, 175, 220);
		addButton(Podcast, 375, 220);
		addButton(Assistant, 575, 220);

	}

	// Functia de adaugare ce are ca variabile componenta si coordonatele unde va fi
	// fixat butonul in interfata
	private void addButton(Componenta comp, int x, int y) {
		try {
			comp.creeazaComponenta();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JButton button = new JButton(comp.nume());

		button.setBounds(x, y, 135, 135);
		button.setIcon(comp.deseneaza());
		button.setOpaque(false);
		button.setContentAreaFilled(false);
		button.setBorderPainted(false);
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) { // Mesajul afisat la apasarea unui buton
				JOptionPane.showMessageDialog(Product_JFrame.this, "Se deschide aplicatia " + comp.nume());
			}
		});

		add(button);
	}

	public void makeVisible() { // Functia makeVisibile() face fereastra vizibila

		setLocationRelativeTo(null);
		setLayout(null);
		setVisible(true);
	}
}
