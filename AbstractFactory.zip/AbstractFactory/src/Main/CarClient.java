package Main;

import Componente.Componenta;
import GUI.BluetoothStock;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;

import Componente.AndroidMessages;
import Componente.AppleCalendar;
import Componente.AppleMaps;
import Componente.AppleMusic;
import Componente.ApplePodcast;
import Componente.Assistant;
import Componente.Calendar;
import Componente.GPS;
import Componente.GoogleAssistant;
import Componente.GoogleCalendar;
import Componente.GoogleMaps;
import Componente.IMessage;
import Componente.Messaging;
import Componente.Music;
import Componente.PocketCasts;
import Componente.Podcast;
import Componente.Siri;
import Componente.Spotify;
import Factories.AppleCarPlayFactory;
import Factories.AndroidAutoFactory;
import Factories.CarFactory;

/*
 * Clasa Main a proiectului in care are loc utilizarea 
 * diferitelor componente si fabrici pentru sisteme auto
 */

public class CarClient {
	public static void main(String[] args) throws IOException {

		SwingUtilities.invokeLater(BluetoothStock::new); // Programeaza crearea si afisarea interfetei grafice

	}
}
